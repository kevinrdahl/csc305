Kevin Dahl
V00759340

FEATURES:
=========
Renders an arbitrary number of spheres and planes
These may have their own colours and reflectivity
Multiple light sources, which also have colour
Supersample antialiasing
